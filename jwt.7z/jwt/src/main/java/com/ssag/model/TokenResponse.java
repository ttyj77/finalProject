package com.ssag.model;

import org.springframework.stereotype.Component;

@Component
public class TokenResponse {
	private String accessToken;
	private String tokenType;
}
