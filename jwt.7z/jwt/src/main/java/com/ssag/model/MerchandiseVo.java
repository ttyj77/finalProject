package com.ssag.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component("merchandiseVo")
public class MerchandiseVo {

	
	private int code;
	
	private int companycode;
	
	private int ingredientcode;
	
	private String itemname;
	
	private int cost;
	
	private int outofstock;
	
	private String link;
	
	private String imglink;
	
}
