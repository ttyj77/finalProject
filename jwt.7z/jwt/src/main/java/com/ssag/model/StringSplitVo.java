package com.ssag.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component("stringSplitVo")
public class StringSplitVo {

	private String name;
	private String link;
	private String imglink;
	private String ingredientNameList;
	
}
