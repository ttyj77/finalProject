package com.ssag.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component("similarnameVo")
@Data
public class SimilarnameVo {

	
	private String similar;
	private String originalname;
	
	private IngredientVo ingredientVo22;
	private MerchandiseVo merchandiseVo22;
}
